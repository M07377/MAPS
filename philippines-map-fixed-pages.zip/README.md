# Philippines Map — Interactive Atlas (Fixed)

This version is GitHub Pages–ready and includes the full map code.

## Deploy (GitHub Pages)
1) Create a new public repo (e.g. `philippines-map`).
2) Upload *all files* in this folder to the repo root.
3) In **Settings → Pages**: Source = *Deploy from a branch*, Branch = `main`, Folder = `/ (root)`.
4) Open: `https://YOUR_USERNAME.github.io/philippines-map/`

If you see a blank page, ensure `index.html` is not empty and your repo is public.
